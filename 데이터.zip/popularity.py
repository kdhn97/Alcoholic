from datetime import datetime, timedelta
import requests
import json

def get_search_volume(keyword, client_id, client_secret):
   # 현재 날짜를 종료일로 설정
   end_date = datetime.now().strftime("%Y-%m-%d")
   # 1년 전 날짜를 시작일로 설정
   start_date = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
   
   # 네이버 API 요청을 위한 데이터 구성
   body = {
       "startDate": start_date,
       "endDate": end_date,
       "timeUnit": "date",
       "keywordGroups": [{ "groupName": keyword, "keywords": [keyword] }]
   }
   
   # 네이버 API에 POST 요청 보내기
   response = requests.post(
       "https://openapi.naver.com/v1/datalab/search", 
       headers={
           "X-Naver-Client-Id": client_id,
           "X-Naver-Client-Secret": client_secret,
           "Content-Type": "application/json"
       },
       json=body
   )
   
   # 응답이 성공적이면 검색량 합계 반환
   if response.status_code == 200:
       data = response.json()
       return sum(item['ratio'] for item in data['results'][0]['data'])
   return None

# 네이버 API 인증 정보
CLIENT_ID = "MdNh08yNomrG4DXpTcMx"
CLIENT_SECRET = "9pdKXm4lo6"

# JSON 파일에서 칵테일 데이터 읽기
with open('cocktails.json', 'r', encoding='utf-8') as file:
   cocktails_data = json.load(file)

# 각 칵테일의 검색량 확인 및 출력
for cocktail in cocktails_data:
   total = get_search_volume(cocktail['en_cocktail_name'], CLIENT_ID, CLIENT_SECRET)
   if total:
       print(f'"{cocktail["en_cocktail_name"]}": {total:.0f}')
